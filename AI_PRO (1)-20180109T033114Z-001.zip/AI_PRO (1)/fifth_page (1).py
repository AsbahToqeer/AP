from appJar import gui

class hello4:


    def __init__(self):

        app = gui("DOCUMENT SCANNER", "1350x710")
        app.setBgImage("done.jpg")
        app.go()

hello4()

