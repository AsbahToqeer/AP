from appJar import gui
import os

class hello4:
    def press(self,app):
        print "OK"
        os.system("python fifth_page.py")

    def __init__(self):

        app = gui("DOCUMENT SCANNER", "1350x710")
        app.setBg("black")
        app.setFont(15)
        app.addTextArea("t1",5,12,2,5)
        app.setTextArea("t1", "HI!! THIS IS OCR.",end="True", callFunction="True")
        self.app = app
        app.addButton("DONE",self.press,10,12)
        app.go()

hello4()

