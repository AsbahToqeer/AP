from appJar import gui
import os
import tkFileDialog
class hello2:
    def press1(self,app):
        print "OK"
        os.system("python third_page.py")
    def press2(self, app):
        #print "cancel"
        #self.app.removeAllWidgets()
        os.system("python fourth_page.py")
    def __init__(self,app):
        self.app = app
        self.app.setBg("black")
        self.app.setFont(15)
        #app.startLabelFrame("Image", 5, 10)
        path = tkFileDialog.askopenfilename(filetypes=[("Image File", '.jpg')])
        self.app.addImage("image", "done.jpg",5,11)
        #app.stopLabe
        # lFrame()
        self.app.addButton("BINARIZE",self.press1,7,10)
        self.app.addButton("RUN OCR", self.press2,7,12)
        self.app.go()

