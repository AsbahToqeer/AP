from appJar import gui
import os

class hello3:
    def press(self,app):
        print "OK"
        os.system("python fourth_page.py")

    def __init__(self):

        app = gui("DOCUMENT SCANNER", "1350x710")
        app.setBg("black")
        app.setFont(15)
        self.app = app
        #app.startLabelFrame("Image", 5, 15,colspan=2,rowspan=3)
        app.addImage("image", "img2.jpg",8,12)
        #app.stopLabelFrame()
        app.addButton("RUN OCR",self.press,9,12)
        app.go()
hello3()

