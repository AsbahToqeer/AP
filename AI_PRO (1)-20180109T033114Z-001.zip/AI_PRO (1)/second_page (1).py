from appJar import gui
import os
import tkFileDialog

class hello2:
    def press1(self,app):
        print "OK"
        os.system("python third_page.py")
    def press2(self, app):
        #print "cancel"
        #self.app.removeAllWidgets()
        os.system("python fourth_page.py")
    def __init__(self,app):
        print "he"
        self.app = app
        self.app.removeAllWidgets()
        self.app.setBg("black")
        self.app.setFont(15)
        in_path = tkFileDialog.askopenfilename()
        print(in_path)
        head, tail = os.path.split(in_path)
        #app.startLabelFrame("Image", 5, 10)
        self.app.addImage("image", tail,5,11)
        #app.stopLabelFrame()
        self.app.addButton("BINARIZE",self.press1,7,10)
        self.app.addButton("RUN OCR", self.press2,7,12)

if __name__ == '__main__':
    app = gui("DOCUMENT SCANNER", "1350x710")

    hello2(app)
    app.go()